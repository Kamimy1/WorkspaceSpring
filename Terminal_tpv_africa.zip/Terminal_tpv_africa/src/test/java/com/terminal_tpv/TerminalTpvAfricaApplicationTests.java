package com.terminal_tpv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TerminalTpvAfricaApplicationTests {

	@Test
	void contextLoads() {
	}

}
